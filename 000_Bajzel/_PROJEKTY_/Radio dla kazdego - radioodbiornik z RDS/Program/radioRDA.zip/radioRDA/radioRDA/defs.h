/*
 * defs.h
 *
 * Created: 2015-12-31 07:37:28
 *  Author: dsosnowski
 */ 


#ifndef DEFS_H_
#define DEFS_H_


#define MAIN_CLK			8000000
#define F_CPU				MAIN_CLK
#define MAIN_DELAY			3

#define REFRESH_RDS_DELAY	(100 / MAIN_DELAY)
#define REFRESH_DISP_DELAY	(200 / MAIN_DELAY)
#define REFRESH_UI_TIME		(4000 / MAIN_DELAY)
#define REFRESH_TEXT_TIME	(5000 / MAIN_DELAY)
#define REFRESH_TEXT_DELAY	(1000 / MAIN_DELAY)

#define COM_PORT			PORTD
#define COM_DDR				DDRD
#define COM_PIN				PIND
#define COM_RX_PIN			0
#define COM_TX_PIN			1

#define LCD_DB_PORT			PORTC
#define LCD_DB_DDR			DDRC
#define LCD_DB4				0
#define LCD_DB5				1
#define LCD_DB6				2
#define LCD_DB7				3

#define LCD_COM_PORT		PORTB
#define LCD_COM_DDR			DDRB
#define LCD_RS				2
#define LCD_BKL				3		//L active
#define LCD_EN				4

#define UI_PORT				PORTD
#define UI_DDR				DDRD
#define UI_IN				PIND
#define IMP1_A				2
#define IMP1_B				3
#define IMP2_A				6
#define IMP2_B				7
#define SW1_PIN				4
#define SW2_PIN				5


#endif /* DEFS_H_ */