/*
 * lcd.c
 *
 *  Created on: 2011-02-18
 *      Author: Damian Sosnowski
 *
 *      LCD HD44780 drivers
 */

#include "defs.h"
//#define F_CPU		MAIN_CLK
#include <avr/io.h>
#include <util/delay.h>
#include "lcd.h"

//for lcd wires
/*#define LCD_DB_PORT			LCD_PORT
#define LCD_DB4				0
#define LCD_DB5				1
#define LCD_DB6				2
#define LCD_DB7				3

#define LCD_COM_PORT		LCD2_PORT
#define LCD_RS				3
#define LCD_EN				4
*/

// Komendy steruj�ce wy�wietlaczem
#define LCDC_CLS		0x01
#define LCDC_HOME		0x02
#define LCDC_MODE		0x04
	#define LCDC_MODER		0x02
	#define LCDC_MODEL		0
	#define LCDC_MODEMOVE	0x01
#define LCDC_ON 		0x08
	#define LCDC_ONDISPLAY	0x04
	#define LCDC_ONCURSOR	0x02
	#define LCDC_ONBLINK	0x01
#define LCDC_SHIFT		0x10
	#define LCDC_SHIFTDISP	0x08
	#define LCDC_SHIFTR		0x04
	#define LCDC_SHIFTL		0
#define LCDC_FUNC		0x20
	#define LCDC_FUNC8b		0x10
	#define LCDC_FUNC4b		0
	#define LCDC_FUNC2L		0x08
	#define LCDC_FUNC1L		0
	#define LCDC_FUNC5x10	0x4
	#define LCDC_FUNC5x7	0
#define LCDC_CGA		0x40
#define LCDC_DDA		0x80

#define MAX_SPEC_CHARS		8


static void LCDSendHalf(char byte);
static void LCDSendByte(char data);

const char space[8] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
//const char space[8] = {0x04, 0x0E, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x1F};
//const char hon[8] = {0x04, 0x0E, 0x1F, 0x00, 0x1F, 0x1F, 0x1F, 0x1F};
//const char coff[8] = {0x1F, 0x0E, 0x04, 0x00, 0x00, 0x00, 0x00, 0x1F};
//const char con[8] = {0x1F, 0x0E, 0x04, 0x00, 0x1F, 0x1F, 0x1F, 0x1F};

//---------------------------------------------------
void LCDInit(void)
{
	//inits ports
	LCD_DB_PORT |= (1<<LCD_DB4 | 1<<LCD_DB5 | 1<<LCD_DB6 | 1<<LCD_DB7);
	LCD_COM_PORT |= (1<<LCD_RS | 1<<LCD_BKL | 1<<LCD_EN);
	LCD_DB_DDR |= (1<<LCD_DB4 | 1<<LCD_DB5 | 1<<LCD_DB6 | 1<<LCD_DB7);
	LCD_COM_DDR |= (1<<LCD_RS | 1<<LCD_BKL | 1<<LCD_EN);
	

	_delay_ms(10);
	LCD_COM_PORT &= ~(1<<LCD_RS);
	_delay_ms(20);
	LCDSendHalf((LCDC_FUNC|LCDC_FUNC8b) >> 0x04);
	_delay_ms(10);
	LCDSendHalf((LCDC_FUNC|LCDC_FUNC8b) >> 0x04);
	_delay_ms(2);
	LCDSendHalf((LCDC_FUNC|LCDC_FUNC8b) >> 0x04);
	_delay_ms(2);
	LCDSendHalf((LCDC_FUNC|LCDC_FUNC4b) >> 0x04);
	_delay_ms(2);

	LCDCommand(LCDC_FUNC|LCDC_FUNC4b|LCDC_FUNC2L|LCDC_FUNC5x7);
	LCDCommand(LCDC_ON);
	LCDClear();
	LCDCommand(LCDC_MODE|LCDC_MODER);
	LCDCommand(LCDC_ON|LCDC_ONDISPLAY);

	//LCDSetSpecChar(0, space);
}

//---------------------------------------------------
static void LCDSendHalf(char byte)
{
	LCD_COM_PORT |= (1<<LCD_EN);
	LCD_DB_PORT &= ~(0x0F);
	LCD_DB_PORT |= (0x0F & byte);
	LCD_COM_PORT &= ~(1<<LCD_EN);	
	_delay_ms(1);
}

//---------------------------------------------------
static void LCDSendByte(char data)
{
	LCDSendHalf(data>>0x04);
	LCDSendHalf(data);
	//for the lowest possible power consumption:	
	LCD_DB_PORT  |= (1<<LCD_DB4 | 1<<LCD_DB5 | 1<<LCD_DB6 | 1<<LCD_DB7);
	LCD_COM_PORT |= (1<<LCD_RS| 1<<LCD_EN);
	//DelayMs(1);
}

//---------------------------------------------------
void LCDCommand(char command)
{
	LCD_COM_PORT &= ~(1<<LCD_RS);
	LCDSendByte(command);
}

//---------------------------------------------------
void LCDData(char data)
{
	LCD_COM_PORT |= (1<<LCD_RS);
	LCDSendByte(data);
}

//---------------------------------------------------
void LCDClear(void)
{
	LCDCommand(LCDC_CLS);
	_delay_ms(2);
}

//---------------------------------------------------
void LCDHome(void)
{
	LCDCommand(LCDC_HOME);
}

//---------------------------------------------------
void LCDText(char *str)
{
	while(*str) LCDData(*str++);
}

//---------------------------------------------------
void LCDLocate(char lcd_y, char lcd_x)
{
	LCDCommand((lcd_y*0x40+lcd_x)|0x80);
}

//---------------------------------------------------
void LCDMsg(char lcd_y, char lcd_x, char *str)
{
	LCDLocate(lcd_y, lcd_x);
	LCDText(str);
}

//---------------------------------------------------
void LCDValue4(uint16_t val)
{
	char blink = 0;
	char d;
	
	if(val > 9999) val = 9999;
		
	d = (val / 1000);
	if (d) blink = 1;
	if (blink)
	LCDData(d + '0');
	else
	LCDData(' ');

	val %= 1000;
	d = (val / 100);
	if (d) blink = 1;
	if (blink)
	LCDData(d + '0');
	else
	LCDData(' ');
	
	val %= 100;
	d = (val / 10);
	if (d) blink = 1;
	if (blink)
	LCDData(d + '0');
	else
	LCDData(' ');

	val %= 10;
	d = (val / 1);
	LCDData(d + '0');
}

//---------------------------------------------------
//if bits 7, 6, 5 sets then exit
void LCDSetSpecs(char* pData)
{
	char count = 0;
	LCDCommand(LCDC_CGA);

	while (count < MAX_SPEC_CHARS * 8)
	{
		if (*pData >= 0xE0) break;
		LCDData(*pData);
		pData++;
		count++;
	}
}

//---------------------------------------------------
void LCDSetSpecChar(char spec, char* pData)
{
	char count;
	if (spec < (MAX_SPEC_CHARS - 1))	//i.e 8-1 = 7
	{
		spec *= 8;
		LCDCommand(LCDC_CGA | spec);
		count = 0;
		while (count < 8)
		{
			LCDData(*pData);
			pData++;
			count++;
		}
	}
}

