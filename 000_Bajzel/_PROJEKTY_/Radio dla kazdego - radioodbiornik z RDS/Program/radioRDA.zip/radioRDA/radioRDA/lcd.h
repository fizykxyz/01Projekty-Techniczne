#ifndef LCD_H
#define LCD_H

#define SPEC_CHAR0		0
#define SPEC_CHAR1		1
#define SPEC_CHAR2		2
#define SPEC_CHAR3		3
#define SPEC_CHAR4		4
#define SPEC_CHAR5		5
#define SPEC_CHAR6		6




//---------------------------------------------------
void LCDInit(void);
void LCDCommand(char command);
void LCDData(char data);
void LCDClear(void);
void LCDHome(void);
void LCDText(char *str);
void LCDLocate(char lcd_y, char lcd_x);
void LCDMsg(char lcd_y, char lcd_x, char *str);
void LCDValue4(uint16_t val);
void LCDTempValue(int temp);
void LCDSetSpecs(char* pData);
void LCDSetSpecChar(char spec, char* pData);


#endif //LCD_H
