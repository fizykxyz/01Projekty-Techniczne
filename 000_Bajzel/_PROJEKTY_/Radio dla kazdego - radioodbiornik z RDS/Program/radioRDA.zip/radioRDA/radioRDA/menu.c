/*
 * menu.c
 *
 * Created: 2016-01-23 01:10:26
 *  Author: Doom
 */ 


#include "defs.h"
#define F_CPU MAIN_CLK
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "lcd.h"
#include "ui.h"
#include "serial.h"
#include "settings.h"
#include "radio.h"
#include "menu.h"

const char disp_spec_space[8] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
const char disp_spec_signal[8] = {0x00, 0x15, 0x15, 0x0A, 0x04, 0x04, 0x04, 0x04};
const char disp_spec_volume[8] = {0x01, 0x03, 0x05, 0x19, 0x19, 0x05, 0x03, 0x01};
const char disp_spec_rds[8] = {0x1C, 0x12, 0x1C, 0x14, 0x12, 0x00, 0x00, 0x00};
const char disp_spec_stereo[8] = {0x03, 0x04, 0x02, 0x01, 0x06, 0x00, 0x00, 0x00};	

#define DISP_SIGNAL_THRESHOLD		40
#define DISP_SPACE_CHAR				0
#define DISP_SIGNAL_CHAR			1
#define DISP_VOLUME_CHAR			2
#define DISP_RDS_CHAR				3
#define DISP_STEREO_CHAR			4
#define DISP_SIGNAL_LEVEL			5
#define DISP_VOLUME_LEVEL			6

#define MENU_DISPLAY_SIZE			32
#define MENU_MAIN_TEXT_SIZE			8
#define MENU_SECOND_TEXT_SIZE		64

struct {
	char display[MENU_DISPLAY_SIZE + 1];
	char disp_i; 
	char main_text[MENU_MAIN_TEXT_SIZE + 1];
	char second_text[MENU_SECOND_TEXT_SIZE + 1];	
	char second_len;
	char second_offset;
} menu;

const char program[16] = "   Program  0   ";
const char program_sett[16] = ">> Program  0 <<";

//----------------------------------------------------
void MenuDispInit(void) {
	LCDSetSpecChar(DISP_SPACE_CHAR, disp_spec_space);	
	LCDSetSpecChar(DISP_SIGNAL_CHAR, disp_spec_signal);
	LCDSetSpecChar(DISP_VOLUME_CHAR, disp_spec_volume);
	LCDSetSpecChar(DISP_RDS_CHAR, disp_spec_rds);
	LCDSetSpecChar(DISP_STEREO_CHAR, disp_spec_stereo);
}

//----------------------------------------------------
void MenuDispMain(char mode) {

	char v;

	menu.display[MENU_DISPLAY_SIZE] = 0;
	
	//-----------------------------------------
	menu.disp_i = 0;	
	v = RadioSignalGet();
	if (v > DISP_SIGNAL_THRESHOLD) 
		v -= DISP_SIGNAL_THRESHOLD;
	else 
		v = 0;
	v /= 3;
	MenuDispLevel(v, DISP_SIGNAL_LEVEL);
	MenuDispAdd(DISP_SIGNAL_CHAR);
	if (RadioRdsGet()) 
		MenuDispAdd(DISP_RDS_CHAR);
	else
		MenuDispAdd(' ');
	
	//-----------------------------------------
	menu.disp_i = 13;
	if (RadioStereoGet()) 
		MenuDispAdd(DISP_STEREO_CHAR);
	else
		MenuDispAdd(' ');
	
	menu.disp_i = 14;
	v = SettVolGet();
	v /= 2;
	MenuDispAdd(DISP_VOLUME_CHAR);
	MenuDispLevel(v, DISP_VOLUME_LEVEL);
		
	//-----------------------------------------
	menu.disp_i = 4;
	MenuDispAddLen(&menu.main_text[0], 8);
	
	menu.disp_i = 16;
	if (mode == 0) {
		MenuDispAddLen(&menu.second_text[0], 16);	
	} else {
		MenuDispAddSecondText(menu.disp_i, 16);
	}

	//-----------------------------------------
	MenuDispSend(&menu.display[0]);		
}

//---------------------------------------------------
void MenuDispLevel(char val, char bank) {
	char custom_spec[8];
	char i;
	
	i = 0;
	while (i < 8) {
		custom_spec[i] = 0x00;
		if ((i < 7) && (val >= (7 - i))) custom_spec[i] = 0x1F;
		if (i == 7) custom_spec[i] = 0x1F;
		i++;
	}

	MenuDispAdd(bank);
	LCDSetSpecChar(bank, custom_spec);
}

//---------------------------------------------------
void MenuDispAdd(char data) {
	if (menu.disp_i < MENU_DISPLAY_SIZE) {
		menu.display[menu.disp_i] = data;	
		menu.disp_i++;
	}
}

//---------------------------------------------------
void MenuDispAddLen(char *data, char len) {	
	while (len) {
		if (menu.disp_i < MENU_DISPLAY_SIZE) {
			menu.display[menu.disp_i] = *data;
			menu.disp_i++;
			data++;
		}
		len--;
	}
}

//---------------------------------------------------
void MenuDispAddSecondText(char dst_i, char len) {
	char i;
	char *dst;
	
	i = menu.second_offset;
	dst = &menu.display[dst_i];
	
	while (len) {
		if (i > (menu.second_len + 2)) i = 0;
		
		if (i < menu.second_len) {
			*dst = menu.second_text[i];
		} else {
			*dst = ' ';
		}
		i++;	
		dst++;
		len--;
	}
}

//---------------------------------------------------
void MenuDispSend(char *str) {
	char i;
	
	LCDLocate(0,0);	
	i = 0;
	while (i < 16) {
		LCDData(*str);
		str++;
		i++;
	}
	LCDLocate(1,0);
	i = 0;
	while (i < 16) {
		LCDData(*str);
		str++;
		i++;
	}
}

//---------------------------------------------------
void MenuMainTextFreq(uint16_t val) {
	char d;
	char *dst;
	
	dst = &menu.main_text[0];	
	d = (val / 1000);
	if (d > 0)
		*dst = (d + '0');
	else
		*dst = (' ');
	dst++;
	 
	val %= 1000;
	d = (val / 100);
	*dst = (d + '0'); dst++;
	
	val %= 100;
	d = (val / 10);
	*dst = (d + '0'); dst++;

	*dst = ('.'); dst++;
	
	val %= 10;
	*dst = (val + '0'); dst++;
	
	*dst = ('M'); dst++;
	*dst = ('H'); dst++;
	*dst = ('z');
}

//---------------------------------------------------
void MenuSecondTextProgram (char val, char mode) {
	char i;
	char *dst;
	char *src;
	//---Program--1---
	i = 0;
	if (mode == 0)
		src = &program[0];
	else
		src = &program_sett[0];
			
	dst = &menu.second_text[0];
	
	if (val == 0) {
		while (i < 16) {
			*dst = ' ';
			dst++;
			i++;
		}
		*dst = 0;
	} else {	
		while (i < 16) {
			*dst = *src;
			src++;
			dst++;
			i++;
		}
		*dst = 0;
		menu.second_text[12] = (val + '0');
	}
}

//---------------------------------------------------
void MenuMainTextGet(char *src) {
	char status;
	char i;
	char *dst;
	
	dst = &menu.main_text[0];
	i = 0;
	status = 0;
	
	while (status == 0) {
		//if ((*src != 0) && (*src != '\n') && (*src != '\r')) {
		if ((*src >= ' ') && (*src <= 'z')) {
				*dst = *src;
				src++;
				dst++;
				i++;
		} else {
			*dst = 0;
			dst++;
			i++;
		}
		if (i >= MENU_MAIN_TEXT_SIZE) status = 1;
	}
	*dst = 0;
}

//---------------------------------------------------
void MenuSecondTextGet(char *src) {
	char status;
	char i;
	char *dst;
	
	menu.second_len = 0;
	dst = &menu.second_text[0];
	i = 0;
	status = 0;
	
	while (status == 0) {
		//if ((*src != 0) && (*src != '\n') && (*src != '\r')) {
		if ((*src >= ' ') && (*src <= 'z')) {
			*dst = *src;
			src++;
			dst++;
			i++;
			menu.second_len++;
		} else {
			*dst = 0;
			dst++;
			i++;
		}
		if (i >= MENU_SECOND_TEXT_SIZE) status = 1;
	}
	*dst = 0;
}

//---------------------------------------------------
void MenuSecondTextScroll(char restart) {
	if (restart) {
		menu.second_len = 0;
		menu.second_offset = 0;
	} else {
		menu.second_offset++;
		if (menu.second_offset >= menu.second_len) menu.second_offset = 0;
	}
}


