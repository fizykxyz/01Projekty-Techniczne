/*
 * menu.h
 *
 * Created: 2016-01-23 01:14:56
 *  Author: Doom
 */ 


#ifndef MENU_H_
#define MENU_H_


void MenuDispInit(void);
void MenuDispMain(char mode);
void MenuDispLevel(char val, char bank);
void MenuDispAdd(char data);
void MenuDispAddLen(char *data, char len);
void MenuDispAddSecondText(char dst_i, char len);
void MenuDispSend(char *str);

void MenuMainTextFreq(uint16_t val);
void MenuSecondTextProgram (char val, char mode);
void MenuMainTextGet(char *src);
void MenuSecondTextGet(char *src);
void MenuSecondTextScroll(char restart);

#endif /* MENU_H_ */