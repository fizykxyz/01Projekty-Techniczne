/*
 * radio.c
 *
 * Created: 2016-01-20 11:19:42
 *  Author: dsosnowski
 */ 


#include "defs.h"
#define F_CPU MAIN_CLK
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "lcd.h"
#include "ui.h"
#include "serial.h"
#include "settings.h"
#include "radio.h"

//-----------------------------------------
/*#define I2C_PORT		PORTC
#define I2C_DDR			DDRC
#define I2C_PIN			PINC
#define SDA				4
#define SCL				5
*/

//-----------------------------------------
#define I2C_FREQ_VAL			24
#define I2C_SLAVE_ADR			0x20	
#define I2C_SLAVE_RADR			(I2C_SLAVE_ADR + 1)	
#define I2C_SLAVE_REG_ADR		(I2C_SLAVE_ADR + 2)

#define I2C_STATUS_START		0x08
#define I2C_STATUS_SLAR_ACK		0x40
#define I2C_STATUS_DATAR_ACK	0x50
#define I2C_STATUS_DATAR_NACK	0x58

#define I2C_STATUS_SLAW_ACK		0x18
#define I2C_STATUS_DATAW_ACK	0x28
#define I2C_STATUS_DATAW_NACK	0x30

#define I2C_NO_ACK				0
#define I2C_ACK					1
#define I2C_LAST_DATA			2

#define RADIO_STATUS_IDLE		0
#define RADIO_STATUS_OK			1
#define RADIO_STATUS_I2C_ERR	2
#define RADIO_STATUS_ERR		3

#define RADIO_WRITE_ADR			0x02
#define RADIO_WRITE_WORDS		8			
#define RADIO_READ_ADR			0x0A
#define RADIO_READ_WORDS		6



//------------------------------------------------------
#define RADIO_REG_CHIPID		0x00
#define RADIO_CHIP_ID				0x0058

#define RADIO_REG_CTRL			0x02
#define RADIO_REG_CTRL_OUTPUT		0x8000
#define RADIO_REG_CTRL_UNMUTE		0x4000
#define RADIO_REG_CTRL_MONO			0x2000
#define RADIO_REG_CTRL_BASS			0x1000
#define RADIO_REG_CTRL_SEEKUP		0x0200
#define RADIO_REG_CTRL_SEEK			0x0100
#define RADIO_REG_CTRL_RDS			0x0008
#define RADIO_REG_CTRL_NEW			0x0004
#define RADIO_REG_CTRL_RESET		0x0002
#define RADIO_REG_CTRL_ENABLE		0x0001

#define RADIO_REG_CHAN			0x03
#define RADIO_REG_CHAN_SPACE		0x0003
#define RADIO_REG_CHAN_SPACE_100	0x0000
#define RADIO_REG_CHAN_BAND			0x000C
#define RADIO_REG_CHAN_BAND_FM		0x0000
#define RADIO_REG_CHAN_BAND_FMWORLD 0x0008
#define RADIO_REG_CHAN_TUNE			0x0010
#define RADIO_REG_CHAN_TEST			0x0020
#define RADIO_REG_CHAN_NR			0x7FC0

#define RADIO_REG_R4			0x04
#define RADIO_REG_R4_EM50			0x0800
#define RADIO_REG_R4_RES			0x0400
#define RADIO_REG_R4_SOFTMUTE		0x0200
#define RADIO_REG_R4_AFC			0x0100

#define RADIO_REG_VOL			0x05
#define RADIO_REG_VOL_DEFAULT		0x8880
#define RADIO_REG_VOL_VOL			0x000F

#define RADIO_REG_RA			0x0A
#define RADIO_REG_RA_RDS			0x8000
#define RADIO_REG_RA_RDSBLOCK		0x0800
#define RADIO_REG_RA_STEREO			0x0400
#define RADIO_REG_RA_NR				0x03FF

#define RADIO_REG_RB			0x0B
#define RADIO_REG_RB_FMTRUE			0x0100
#define RADIO_REG_RB_FMREADY		0x0080

#define RADIO_REG_RDSA			0x0C
#define RADIO_REG_RDSB			0x0D
#define RADIO_REG_RDSC			0x0E
#define RADIO_REG_RDSD			0x0F


#define RADIO_RDS_STATION_LEN		8
#define RADIO_RDS_STATION_0A_OFF	0
//#define RADIO_RDS_STATION_0B_OFF	8

#define RADIO_RDS_TEXT_LEN			64
#define RADIO_RDS_TEXT_2A_OFF		0
//#define RADIO_RDS_TEXT_2B_OFF	64





struct {
	int16_t status;
	uint16_t buff[16];
	char signal;
	char stereo;
	char rds;
	char mute;
} radio;

struct {
	char station[RADIO_RDS_STATION_LEN + 1];
	char check_station[RADIO_RDS_STATION_LEN + 1];
	char text[RADIO_RDS_TEXT_LEN + 1];
	char check_text[RADIO_RDS_TEXT_LEN + 1];
	char station_ready;
	char text_ready;		
} rds;


//-----------------------------------------
int16_t RadioInit(void) {
	char result;
	char i;
	
	I2c_init();
	_delay_ms(50);

	//-----------------------------------------------
	i = 0;
	result = RADIO_STATUS_IDLE;
	while (result == RADIO_STATUS_IDLE) {
		
		result = I2c_open(I2C_SLAVE_ADR);
		I2c_stop();
		_delay_ms(50);
		
		SerialAdd("\ri2c init ");
		SerialAddVal(result);
		SerialSend();		

		if (result != RADIO_STATUS_OK){		
			result = RADIO_STATUS_IDLE;
		}
		
		i++;
		if (i > 5) result = RADIO_STATUS_ERR;
	}
	
	radio.buff[RADIO_REG_CHIPID] = RADIO_CHIP_ID;
	radio.buff[1] = 0x0000;		//not used
	radio.buff[RADIO_REG_CTRL] = (RADIO_REG_CTRL_ENABLE | RADIO_REG_CTRL_OUTPUT |
								  RADIO_REG_CTRL_BASS | RADIO_REG_CTRL_RDS | 
								  RADIO_REG_CTRL_NEW);
	radio.buff[RADIO_REG_CHAN] = (RADIO_REG_CHAN_BAND_FM | RADIO_REG_CHAN_SPACE_100);
    radio.buff[RADIO_REG_R4] = (RADIO_REG_R4_EM50 | RADIO_REG_R4_SOFTMUTE);
    radio.buff[RADIO_REG_VOL] = RADIO_REG_VOL_DEFAULT;  
	radio.buff[6] = 0x0000;		//not used
	radio.buff[7] = 0x0000;		//not used
	radio.buff[8] = 0x0000;		//not used
	radio.buff[9] = 0x0000;		//not used
	radio.mute = 1;
	
	if (result == RADIO_STATUS_OK)
	{
		RadioWriteReg(RADIO_REG_CTRL, (RADIO_REG_CTRL_RESET | RADIO_REG_CTRL_ENABLE));
		_delay_ms(10);
		RadioWriteReg(RADIO_REG_CTRL, (RADIO_REG_CTRL_ENABLE));
		_delay_ms(100);
		radio.buff[RADIO_REG_CTRL] = (RADIO_REG_CTRL_ENABLE | RADIO_REG_CTRL_OUTPUT |
									  RADIO_REG_CTRL_BASS | RADIO_REG_CTRL_RDS | 
									  RADIO_REG_CTRL_NEW);
		RadioWrite();
	}
	
	radio.status = result;
	return radio.status;
}

//-----------------------------------------
int16_t RadioRead(void) {
	char result;
	char reg;
	char i;
	
	result = I2c_open(I2C_SLAVE_RADR);
	if (result == RADIO_STATUS_OK)
	{
		//SerialAdd("\rRadio read:");
		i = 0;
		while (i < RADIO_READ_WORDS) {
			I2c_read(&reg, I2C_ACK);
			radio.buff[RADIO_READ_ADR + i] = (reg << 8);

			if (i == (RADIO_READ_WORDS - 1)) {
				I2c_read(&reg, I2C_NO_ACK);
			} else {
				I2c_read(&reg, I2C_ACK);
			}
			radio.buff[RADIO_READ_ADR + i] += (reg);
			
			//SerialAddHex(radio.buff[RADIO_READ_ADR + i]);
			i++;
		}		
		//SerialSend();
	}
	
	I2c_stop();
	radio.status = result;
	return radio.status;
}

//-----------------------------------------
int16_t RadioWrite(void) {
	char result;
	char reg;
	char i;
	
	result = I2c_open(I2C_SLAVE_ADR);
	if (result == RADIO_STATUS_OK)
	{
		//SerialAdd("\rRadio write:");
		i = 0;
		while (i < RADIO_WRITE_WORDS) {			
			reg = (char)(radio.buff[RADIO_WRITE_ADR + i] >> 8);
			I2c_write(reg);

			reg = (char)(radio.buff[RADIO_WRITE_ADR + i] & 0xFF);
			I2c_write(reg);

			//SerialAddHex(radio.buff[RADIO_WRITE_ADR + i]);
			i++;
		}
		//SerialSend();
	}
	
	I2c_stop();
	radio.status = result;
	return radio.status;
}

//-----------------------------------------
int16_t RadioWriteReg(char i, uint16_t val) {
	char result;
	char reg;

	if ((i >= RADIO_WRITE_ADR) && (i < (RADIO_WRITE_ADR + RADIO_WRITE_WORDS))) {	
		result = I2c_open(I2C_SLAVE_REG_ADR);
		if (result == RADIO_STATUS_OK)
		{
			radio.buff[i] = val;
			I2c_write(i);

			reg = (char)(radio.buff[i] >> 8);
			I2c_write(reg);

			reg = (char)(radio.buff[i] & 0xFF);
			I2c_write(reg);

			//SerialAdd("\rRadio reg write:");
			//SerialAddHex(radio.buff[i]);
			//SerialSend();
		}
	
		I2c_stop();
		radio.status = result;
	}
	return radio.status;
}

//-----------------------------------------
uint16_t RadioFreqSet(uint16_t freq) {
	uint16_t reg_val;
		
	if (freq > RADIO_FREQ_MAX) freq = RADIO_FREQ_MAX;
	if (freq < RADIO_FREQ_MIN) freq = RADIO_FREQ_MIN;
	freq -= RADIO_FREQ_MIN;
	
	reg_val = (RADIO_REG_CHAN_BAND_FM | RADIO_REG_CHAN_SPACE_100 | RADIO_REG_CHAN_TUNE);
	reg_val += (freq << 6);
	
	RadioWriteReg(RADIO_REG_CHAN, reg_val);
	return radio.buff[RADIO_REG_CHAN];	
}

//-----------------------------------------
uint16_t RadioVolumeSet(uint16_t volume) {
	uint16_t reg_val;
	
	if (volume > RADIO_VOLUME_MAX) volume = RADIO_VOLUME_MAX;
	if (volume < RADIO_VOLUME_MIN) volume = RADIO_VOLUME_MIN;	
	
	if (volume == 0) {
		if (radio.mute == 0) RadioMuteSet(1);
		
		reg_val = RADIO_REG_VOL_DEFAULT;
		RadioWriteReg(RADIO_REG_VOL, reg_val);		
	} else {
		reg_val = RADIO_REG_VOL_DEFAULT;
		reg_val += (volume - 1);	
		RadioWriteReg(RADIO_REG_VOL, reg_val);
		
		if (radio.mute)	RadioMuteSet(0);
	}	
	return radio.buff[RADIO_REG_VOL];
}

//-----------------------------------------
uint16_t RadioMuteSet(char state) {
	if (state) {
		RadioWriteReg(RADIO_REG_CTRL, (RADIO_REG_CTRL_ENABLE | RADIO_REG_CTRL_OUTPUT  | RADIO_REG_CTRL_BASS | RADIO_REG_CTRL_RDS  | RADIO_REG_CTRL_NEW));
		radio.mute = 1;
	} else {
		if (SettVolGet() > 0) {
			RadioWriteReg(RADIO_REG_CTRL, (RADIO_REG_CTRL_ENABLE | RADIO_REG_CTRL_UNMUTE | RADIO_REG_CTRL_OUTPUT | RADIO_REG_CTRL_BASS | RADIO_REG_CTRL_RDS  | RADIO_REG_CTRL_NEW));		
			radio.mute = 0;
		}
	}
	return radio.buff[RADIO_REG_CTRL];
}

//-----------------------------------------
char RadioSignalGet(void) {
	radio.signal = (char)(radio.buff[RADIO_REG_RB] >> 9);
	radio.signal &= 0x7F;
	return radio.signal;
}

//-----------------------------------------
char RadioStereoGet(void) {
	radio.stereo = (radio.buff[RADIO_REG_RA] >> 10);
	radio.stereo &= 0x01;
	return radio.stereo;
}

//-----------------------------------------
char RadioRdsGet(void) {
	radio.rds = (radio.buff[RADIO_REG_RA] >> 12);
	radio.rds &= 0x01;
	return radio.rds;
}

//-----------------------------------------
char RadioRdsReady(void) {
	radio.rds = (radio.buff[RADIO_REG_RA] >> 15);
	radio.rds &= 0x01;
	return radio.rds;
}

//-----------------------------------------
void RadioRdsProcess(void) {
	char group;
	char pos;
	
	char data1;
	char data2;
	char data3;
	char data4;
	char datapass;
	
	static char prev_pos_station;
	static char station_index;
	static char prev_pos_text;
	static char text_index;
		
	group = 0x0A;
	group += (char)((radio.buff[RADIO_REG_RDSB] >> 8) & 0xF0);
	group += (char)((radio.buff[RADIO_REG_RDSB] >> 11) & 0x01);

	switch (group) {
		case 0x0A:
			//if not yet ready
			if (rds.station_ready == 0) {
				//get text position
				pos	= (char)(radio.buff[RADIO_REG_RDSB] & 0x03);
				pos *= 2;
			
				//if next data
				if (pos != prev_pos_station) {
					prev_pos_station = pos;
			
					data1 = (char)((radio.buff[RADIO_REG_RDSD] >> 8) & 0xFF);
					data2 = (char)((radio.buff[RADIO_REG_RDSD]) & 0xFF);
			
					//if twice the same
					if ((rds.check_station[pos] == data1) && (rds.check_station[pos+1] == data2)) {
						rds.station[pos] = data1;	
						rds.station[pos+1] = data2;
						rds.station[RADIO_RDS_STATION_LEN] = 0;
	
						//complete all blocks
						if (pos == station_index) {
							station_index += 2;
							if (station_index == 8) {
								prev_pos_station = 0;
								station_index = 0;
								rds.station_ready = 1;
							}
						}
					//if not the same	
					} else {
						station_index = 0;
						rds.check_station[pos] = data1;
						rds.check_station[pos+1] = data2;	
					}
				}
			}			
		break;
		//---------------------------------------------------------		
		case 0x2A:
			//if not yet ready
			//if (rds.text_ready == 0) {
			pos = (char)((radio.buff[RADIO_REG_RDSB]) & 0x0F);				
			pos *= 4;
			if (pos < (RADIO_RDS_TEXT_LEN - 4)) {
			
				//if next data
				if (pos != prev_pos_text) {
					prev_pos_text = pos;
				
					data1 = (char)((radio.buff[RADIO_REG_RDSC] >> 8) & 0xFF);
					data2 = (char)((radio.buff[RADIO_REG_RDSC]) & 0xFF);
					data3 = (char)((radio.buff[RADIO_REG_RDSD] >> 8) & 0xFF);
					data4 = (char)((radio.buff[RADIO_REG_RDSD]) & 0xFF);
					
					datapass = 1;
					
					if (rds.check_text[pos+0] == data1) {
						rds.text[pos+0] = data1;						
					} else {
						rds.check_text[pos+0] = data1;
						datapass = 0;
					}

					if (rds.check_text[pos+1] == data2) {
						rds.text[pos+1] = data2;
					} else {
						rds.check_text[pos+1] = data2;
						datapass = 0;
					}
					
					if (rds.check_text[pos+2] == data3) {
						rds.text[pos+2] = data3;
					} else {
						rds.check_text[pos+2] = data3;
						datapass = 0;
					}
					
					if (rds.check_text[pos+3] == data4) {
						rds.text[pos+3] = data4;
					} else {
						rds.check_text[pos+3] = data4;
						datapass = 0;
					}
					
					rds.text[RADIO_RDS_TEXT_LEN] = 0;
					
					if (datapass == 0) {
						text_index = 0;
					} else {
						if (pos == text_index) {
							text_index += 4;
						}							
					}
					
					if (text_index >= 16)
						rds.text_ready = text_index;
					else
						rds.text_ready = 0;
				}
			}
			//}
		break;		
	}	
}


//-----------------------------------------
char *RadioRdsStationGet(void) {
	return &rds.station[0];
}

//-----------------------------------------
char *RadioRdsTextGet(void) {
	return &rds.text[0];
}

//-----------------------------------------
char RadioRdsStationStatus(char restart) {
	if (restart) rds.station_ready = 0;
	return rds.station_ready;
}

//-----------------------------------------
char RadioRdsTextStatus(char restart) {
	if (restart) rds.text_ready = 0;
	return rds.text_ready;
}

//################### I2C part ################################
//-----------------------------------------
void I2c_init(void)
{
	TWBR = I2C_FREQ_VAL;			//divider
	TWSR = 0x00;					//presc = 0;
	TWCR |= (1<<TWEN);				//enable TWI
}

//-----------------------------------------
char I2c_open(char address)
{
	I2c_stop();
	_delay_ms(5);

	TWCR = (1<<TWINT | 1<<TWSTA | 1<<TWEN);	//send start

	while (!(TWCR & (1<<TWINT)));	//wait for int
	if (TWSR != I2C_STATUS_START) 	//check status
	return RADIO_STATUS_I2C_ERR;		//if not start then error

	TWDR = address;					//prepare address
	TWCR = (1<<TWINT | 1<<TWEN);	//enable send address

	while (!(TWCR & (1<<TWINT)));	//wait for int

	//if no ack then error
	if(!((TWSR == I2C_STATUS_SLAR_ACK) || (TWSR == I2C_STATUS_SLAW_ACK)))
	return RADIO_STATUS_ERR;

	return RADIO_STATUS_OK;			//finished
}

//-----------------------------------------
char I2c_read(char* dest_pt, char ack)
{
	if (ack)
	TWCR = (1<<TWINT | 1<<TWEN | 1<<TWEA);	//clear int, ack
	else
	TWCR = (1<<TWINT | 1<<TWEN);			//clear int, not ack

	while (!(TWCR & (1<<TWINT)));			//wait for int
	if (TWSR == I2C_STATUS_DATAR_ACK)	 	//check status
	{
		*dest_pt = TWDR;
		return RADIO_STATUS_OK;					//finished
	}
	else if (TWSR == I2C_STATUS_DATAR_NACK)
	{
		*dest_pt = TWDR;
		return I2C_LAST_DATA;
	}
	else
	return I2C_STATUS_DATAR_ACK;
}

//-----------------------------------------
char I2c_write(char data)
{
	TWDR = data;
	TWCR = (1<<TWINT | 1<<TWEN);	//enable send address

	while (!(TWCR & (1<<TWINT)));			//wait for int
	if (TWSR == I2C_STATUS_DATAW_ACK)	 	//check status
	return RADIO_STATUS_OK;					//finished
	else if (TWSR == I2C_STATUS_DATAW_NACK)
	return I2C_LAST_DATA;
	else
	return I2C_STATUS_DATAW_ACK;
}

//-----------------------------------------
void I2c_stop(void)
{
	TWCR = (1<<TWINT | 1<<TWEN | 1<<TWSTO);
}
