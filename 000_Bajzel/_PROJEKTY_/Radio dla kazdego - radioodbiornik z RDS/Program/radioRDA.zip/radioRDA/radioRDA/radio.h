/*
 * radio.h
 *
 * Created: 2016-01-20 11:19:57
 *  Author: dsosnowski
 */ 


#ifndef RADIO_H_
#define RADIO_H_


//------------------------------------------------
#define RADIO_FREQ_MAX			1080
#define RADIO_FREQ_MIN			870
#define RADIO_VOLUME_MAX		16
#define RADIO_VOLUME_MIN		0





int16_t RadioInit(void);
int16_t RadioRead(void);
int16_t RadioWrite(void);
int16_t RadioWriteReg(char i, uint16_t val);
uint16_t RadioFreqSet(uint16_t freq);
uint16_t RadioVolumeSet(uint16_t volume);
uint16_t RadioMuteSet(char state);
char RadioSignalGet(void);
char RadioStereoGet(void);
char RadioRdsGet(void);
char RadioRdsReady(void);

void RadioRdsProcess(void);
char *RadioRdsStationGet(void);
char *RadioRdsTextGet(void);
char RadioRdsStationStatus(char restart);
char RadioRdsTextStatus(char restart);

void I2c_init(void);
char I2c_open(char address);
char I2c_read(char* dest_pt, char ack);
char I2c_write(char data);
void I2c_stop(void);


#endif /* RADIO_H_ */