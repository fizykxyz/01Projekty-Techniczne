/*
 * radioRDA.c
 *
 * Created: 2015-12-31 07:08:47
 *  Author: dsosnowski
 */ 


#include "defs.h"
#define F_CPU MAIN_CLK
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "lcd.h"
#include "ui.h"
#include "serial.h"
#include "menu.h"
#include "settings.h"
#include "radio.h"

//--------------------------------------------------------------

struct {
	char button;
	char refresh;
	char ui_refresh;
	char rds_refresh;
	char disp_refresh;
	int16_t ui_time;
	int16_t text_time;
	int16_t text_refresh;
	char scroll;	
} system;

struct {
	char station;
	char text;	
} debug;


//--------------------------------------------------------------
int main(void)
{	
	char startup = (200 / MAIN_DELAY);

	LCDInit();
	SerialInit();
	UiInit();
	SettInit();
	MenuDispInit();
		
	sei();
		
	SerialMsg("\rHELLO ");
	RadioInit();
	
	//--------------------------------------------------------------
    while(1)
    {
		//---------------------------------------------------
		if (startup) {
			startup--;
			if (startup == 0) {
				RadioFreqSet(SettFreqGet());
				RadioVolumeSet(SettVolGet());
				system.text_refresh = REFRESH_TEXT_DELAY;
			}
		}
		
		//---------------------------------------------------
		UiScan();
		if (UiActionGet() > 0) {
			system.button = UiActionGet();
			
			if (SettMode(0) == 0) {
				if (SettFreqChange(system.button)) {
					RadioFreqSet(SettFreqGet());
					RadioRdsStationStatus(1);		//restart rds
					RadioRdsTextStatus(1);			//restart rds
					MenuSecondTextScroll(1);
					system.ui_time = 0;
				}
			} else {
				SettProgramChange(system.button);
				system.ui_time = 0;
			}
			
			if (SettVolChange(system.button)) {
				RadioVolumeSet(SettVolGet()); 
			}
			
			if (system.button == ACTION_SW2) {
				SettMode(1);
				if (SettMode(0) == 0) {				
					SettProgramSave();
				}
				system.ui_time = 0;
			}
			
			if (system.button == ACTION_SW1) {
				if (SettMode(0) > 0) {
					SettMode(1);
				} else {	
					SettProgramNext();
					RadioFreqSet(SettFreqGet());
					RadioRdsStationStatus(1);		//restart rds
					RadioRdsTextStatus(1);			//restart rds
					MenuSecondTextScroll(1);
				}
				system.ui_time = 0;
			}
			
			system.button = 0;
			system.ui_refresh = 1;
			UiActionClear();
		}

		//---------------------------------------------------
		if (system.rds_refresh < REFRESH_RDS_DELAY) {
			system.rds_refresh++;
		} else {
			system.rds_refresh = 0;
			RadioRead();
			RadioRdsProcess();
		}
		
		//---------------------------------------------------
		if (system.ui_time == 0) UiBklVal(INTEFRACE_BKL_MAX);		
		if (system.ui_time < REFRESH_UI_TIME) {
			system.ui_time++;

			if (system.ui_time >= REFRESH_UI_TIME) {
				system.text_time = REFRESH_TEXT_TIME;
				system.text_refresh = 0;

				if (SettMode(0) > 0) SettMode(1);
				UiBklVal(INTEFRACE_BKL_LOW);				
			} else {
				
				system.text_time = 0;
			}
		} else {
			if (system.text_time < REFRESH_TEXT_TIME) {
				system.text_time++;
			}
		}

		//---------------------------------------------------
		if (system.ui_time <= 1) {
			MenuMainTextFreq(SettFreqGet());
			
			if (SettMode(0) == 0)
				MenuSecondTextProgram(SettProgramCheck(), 0);
			else	
				MenuSecondTextProgram(SettProgramGet(), 1);
		}
		
		if (system.text_time >= REFRESH_TEXT_TIME) {
			if (RadioRdsStationStatus(0)) {
				MenuMainTextGet(RadioRdsStationGet());
				RadioRdsStationStatus(1);
				system.text_time = 0;
				system.ui_refresh = 1;
			} else {
				system.text_time = (REFRESH_TEXT_TIME / 4);
			}
			
			if (RadioRdsTextStatus(0)) {
				MenuSecondTextGet(RadioRdsTextGet());
				//RadioRdsTextStatus(1);
				system.text_time = 0;
				system.ui_refresh = 1;
				system.text_refresh = 0;
			}
			
		}
											
		//---------------------------------------------------
		if (system.text_refresh < REFRESH_TEXT_DELAY) {
			system.text_refresh++;
		} else {
			system.text_refresh = 0;
			system.ui_refresh = 1;
			
			MenuSecondTextScroll(0);
		}		

		//---------------------------------------------------
		if (system.disp_refresh <= REFRESH_DISP_DELAY) {
			system.disp_refresh++;
		} else {
			if (system.ui_refresh) {
				system.ui_refresh = 0;
				system.disp_refresh = 0;
				if (system.ui_time < REFRESH_UI_TIME)
					MenuDispMain(0);				
				else
					MenuDispMain(1);				
			}
		}

		//---------------------------------------------------
		UiBklProcess();
		_delay_ms(MAIN_DELAY);
    }
}

//--------------------------------------------------------------
