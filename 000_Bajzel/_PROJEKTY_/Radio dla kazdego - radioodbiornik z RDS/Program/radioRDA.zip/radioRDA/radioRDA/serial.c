/*
 * serial.c
 *
 * Created: 2016-01-15 12:01:58
 *  Author: dsosnowski
 */ 


#include "defs.h"
#define F_CPU MAIN_CLK
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "serial.h"
#include "lcd.h"

#define CORE_CLOCK		F_CPU
#define BAUD_RATE		19200

#define TXD_EN			//COM_PORT |= (1<<COM_EN_PIN)
#define TXD_DIS			//COM_PORT &= ~(1<<COM_EN_PIN)


//command example L1=c,xx,xx\r
//      L                1               =            xx                ,              xx            \r  
//COMMAND_CHAR(1) ADDRESS(1...3), COMMAND_CONTROL PARAM1(1...3) COMMAND_SEPARATOR PARAM2(1...3) COMMAND_ENTER

//-------------------------------------------
struct {
	uint16_t sindex;
	char sbuffer[SERIAL_SBUFFER_SIZE];	
	volatile uint16_t rindex;
	volatile char *rpointer;
	volatile char rbuffer[SERIAL_RBUFFER_SIZE];
	volatile char status;	
} serial;

//-------------------------------------------
struct {
	volatile char status;
	char code;
	char adr;
	char order;	
	int16_t param1;
	int16_t param2;
	char *pt;
	char error;
	char index;
} comm;

//-------------------------------------------
void SerialInit(void)
{
	COM_PORT |= (1<<COM_RX_PIN | 1<<COM_TX_PIN);	//config ports
	COM_DDR |= (1<<COM_TX_PIN);
	 	
	//config USART
	UCSR0A = 0;
	UCSR0B = (1<<RXEN0 | 1<<TXEN0 | 1<<RXCIE0);
	UCSR0C = (1<<UCSZ01 | 1<<UCSZ00);				//8 data, 1 stop, parity none
	UBRR0L = 25;								//1200
	UBRR0H = 0;
	
	CommInit();
}

//----------------------------------------------------
char SerialStatus(void)
{
	return serial.status;
}

//----------------------------------------------------
ISR(USART_RX_vect)
{
	char temp = UDR0;						//get byte from data register	
	//----------------------------------
	if (serial.status == SERIAL_STATUS_IDLE) {
		if (temp == SERIAL_PREFIX) {
			serial.rindex = 0;
			serial.rpointer = &serial.rbuffer[0];
			serial.status = SERIAL_STATUS_READING;
		}
	}
	
	//----------------------------------
	if (serial.status == SERIAL_STATUS_READING) {
		if (serial.rindex < SERIAL_RBUFFER_SIZE) {
			*serial.rpointer = temp;
			serial.rpointer++;
			*serial.rpointer = 0;
			serial.rindex++;
		}
		else
			serial.status = SERIAL_STATUS_IDLE;		//overflow
		
		//----------------------------------
		if (temp == SERIAL_POSTFIX) {
			serial.status = SERIAL_STATUS_READY;
			comm.status = COMMAND_STATUS_READING;
		}
	}
}

//-------------------------------------------
void CommInit(void)
{
	serial.sindex = 0;
	serial.rindex = 0;
	serial.sbuffer[0] = 0;
	serial.rbuffer[0] = 0;
	serial.rpointer = &serial.rbuffer[0];
	serial.status = SERIAL_STATUS_IDLE;
	comm.status = COMMAND_STATUS_IDLE;
}

//-------------------------------------------
void CommClear(void)
{
	comm.status = COMMAND_STATUS_IDLE;
	serial.status = SERIAL_STATUS_IDLE;
}

//-------------------------------------------
char *CommGet(void)
{
	return &comm.order;
}

//-------------------------------------------
char *CommGetPt(void)
{
	return comm.pt;
}

//-------------------------------------------
char CommOrder(void)
{
	return comm.order;
}

//-------------------------------------------
int16_t CommParam1(void)
{
	return comm.param1;
}

//-------------------------------------------
int16_t CommParam2(void)
{
	return comm.param2;
}

//-------------------------------------------
char CommStatus(void)
{
	return comm.status;
}

//-------------------------------------------
char CommError(void)
{
	return comm.error;
}

//-------------------------------------------
char CommProc(void)
{
	if (comm.status == COMMAND_STATUS_READING) 
	{
		comm.index = COMMAND_OFFSET;
		comm.code = serial.rbuffer[comm.index];
		//if (comm.code == master.code) 
		//{
			comm.index++;
			comm.adr = CommValueGet();
			comm.order = 0;
			comm.param1 = 0;
			comm.param2 = 0;
			comm.error = ERROR_NO;
			
			if ((comm.error == 0) && (comm.adr == COMMAND_DEF_ADR))
			//if ((comm.error == 0))
			{
				comm.order = COMMAND_CONTROL;
				if (serial.rbuffer[comm.index] == COMMAND_ENTER)
				{
					comm.status = COMMAND_STATUS_READY;
				} else {
					if (serial.rbuffer[comm.index] == COMMAND_CONTROL) 
					{
						comm.index++;
						if (serial.rbuffer[comm.index] == COMMAND_ENTER) 
						{
							comm.status = COMMAND_STATUS_READY;
						} else {
							comm.order = serial.rbuffer[comm.index];			//order
							comm.pt = 0;
							comm.index++;
							if (serial.rbuffer[comm.index] == COMMAND_ENTER) 
							{
								comm.status = COMMAND_STATUS_READY;
							} else {
								if (serial.rbuffer[comm.index] == COMMAND_SEPARATOR) 
								{
									comm.index++;
									comm.pt = &(serial.rbuffer[comm.index]);
									comm.param1 = CommValueGet();				//param1
									if (comm.error == 0) 
									{
										if (serial.rbuffer[comm.index] == COMMAND_ENTER) 
										{
											comm.status = COMMAND_STATUS_READY;
										} else {
											if (serial.rbuffer[comm.index] == COMMAND_SEPARATOR) 
											{
												comm.index++;
												comm.pt = &(serial.rbuffer[comm.index]);
												comm.param2 = CommValueGet();			//param2
												
												if (comm.error == 0)
												{
													if (serial.rbuffer[comm.index] == COMMAND_ENTER)
													{
														comm.status = COMMAND_STATUS_READY;
													} else comm.error = ERROR_CONTROL;
												} else {
													//check for enter
													comm.error = ERROR_OTHER_PARAM;
													comm.status = COMMAND_STATUS_READY;
												}
											} else comm.error = ERROR_CONTROL;	
										}
									} else  {
										//check for enter
										comm.error = ERROR_OTHER_PARAM;
										comm.status = COMMAND_STATUS_READY;
									}
								} else comm.error = ERROR_CONTROL;
							} 
						}
					} else comm.error = ERROR_CONTROL;
				}
			} else comm.error = ERROR_ADDRESS;
		//} else comm.error = ERROR_COMMAND;
		
		if (comm.error == 0) {
			comm.status = COMMAND_STATUS_READY;
		} else {
			comm.status = COMMAND_STATUS_ERROR;
		}
	}
	return comm.status;
}

//------------------------------------------
int16_t CommValueGet(void)
{
	char minus = 0;
	unsigned int dec1 = 0;
	char dec2 = 0;
	char dec3 = 0;

	if (serial.rbuffer[comm.index] == ' ') comm.index++;
	if (serial.rbuffer[comm.index] == '-') {
		minus = 1;
		comm.index++;
	}
			
	if ((serial.rbuffer[comm.index] >= '0') && (serial.rbuffer[comm.index] <= '9'))
	{
		dec1 = (serial.rbuffer[comm.index] - '0');
		comm.index++;
		
		if ((serial.rbuffer[comm.index] >= '0') && (serial.rbuffer[comm.index] <= '9'))
		{
			dec1 *= 10;
			dec2 = (serial.rbuffer[comm.index] - '0');
			comm.index++;
			
			if ((serial.rbuffer[comm.index] >= '0') && (serial.rbuffer[comm.index] <= '9'))
			{
				dec1 *= 10;
				dec2 *= 10;
				dec3 = (serial.rbuffer[comm.index] - '0');
				comm.index++;
			}
		}
		dec1 += dec2;
		dec1 += dec3;
		if (minus) (dec1 *= -1);
	}
	else
		comm.error = ERROR_PARAM;
	return dec1;
}

//------------------------------------------
uint16_t CommHexValueGet(char *pt)
{
	uint16_t hexval = 0;
	char i = 4;

	if (*pt == ' ') pt++;
	if (*pt == 'x') pt++;
	
	while (i > 0) {
		if ((*pt >= '0') && (*pt <= '9')) {
			hexval <<= 4;
			hexval += (*pt - '0');
		} else if ((*pt >= 'A') && (*pt <= 'F')) {
			hexval <<= 4;
			 hexval += (*pt - 'A' + 10);
		} else if ((*pt >= 'a') && (*pt <= 'f')) {
			hexval <<= 4;
			hexval += (*pt - 'a' + 10);
		} else {
			i = 1;
			//comm.error = ERROR_PARAM;
		}
		pt++;
		i--;
	}
	return hexval;
}


//------------------------------------------
void CommResult(void)
{
	SerialNew();
	SerialAdd("\rS:"); SerialAddVal(comm.status);
	SerialAdd("\rC:"); SerialAddVal(comm.code);	
	SerialAdd("\rA:"); SerialAddVal(comm.adr);
	SerialAdd("\rO:"); SerialAddVal(comm.order);
	SerialAdd("\r1:"); SerialAddVal(comm.param1);
	SerialAdd("\r2:"); SerialAddVal(comm.param2);
	SerialAdd("\rH:"); SerialAddHex(CommHexValueGet(comm.pt));	
	SerialAdd("\rE:"); SerialAddVal(comm.error);
	SerialSend();
}

//------------------------------------------
void SerialNew(void)
{
	serial.sindex = 0;
	serial.sbuffer[serial.sindex] = 0;
}

//------------------------------------------
void SerialMsg(char *src)
{
	serial.sindex = 0;
	SerialAdd(src);
	SerialSend();
}

//------------------------------------------
char SerialAdd(char *src)
{
	char status = 0;
	while (status == 0) {
		if (serial.sindex < SERIAL_SBUFFER_SIZE) {
			if ((*src) && (src)) {
				serial.sbuffer[serial.sindex] = *src;
				serial.sindex++;
				src++;
			} else {
				status = 1;
				serial.sbuffer[serial.sindex] = 0;
			}
		} else status = 2;
	}
	return status;	
}

//------------------------------------------
char SerialAddLen(char *src, char len)
{
	char status = 0;
	while (status == 0) {
		if (serial.sindex < SERIAL_SBUFFER_SIZE) {
			if (len) {
				serial.sbuffer[serial.sindex] = *src;
				serial.sindex++;
				src++;
				len--;
			} else {
				status = 1;
				serial.sbuffer[serial.sindex] = 0;
			}
		} else status = 2;
	}
	return status;
}

//----------------------------------------------
void SerialAddVal(int16_t val)
{
	char *pt = &serial.sbuffer[serial.sindex];
	char pti = 0;
	char blink = 0;
	char d;
	char status = 0;
	uint16_t div = 10000;
	
	if (val < 0) {
		*pt = '-';
		pt++;
		pti++;
		val *= -1;
	}
	
	//if(val > 9999) val = 9999;
	while (status == 0)
	{
		d = (val / div);
		if (d) blink = 1;
		if (div == 1) blink = 1;
		
		if (blink) {
			*pt = (d + '0');
			pt++;
			pti++;
		}
		//else *pt = (' ');
		
		if (div == 1) status = 1;
		val = (val % div);
		div = (div / 10);
	}
	*pt = 0;
	serial.sindex += pti;
}

//----------------------------------------------
void SerialAddHex(uint16_t val)
{
	char *pt = &serial.sbuffer[serial.sindex];
	char d;
	char i = 16;
	
	*pt = 'x';
	pt++;
	
	while (i) {
		i -= 4;
		d = (char)(val >> i);
		d &= 0x0F;
		
		if (d <= 9) {
			*pt = (d + '0');
		} else {
			*pt = (d - 10 + 'A');
		}
		pt++; 
	}
	
	*pt = ' ';
	pt++;	
	*pt = 0;
	serial.sindex += 6;
}

//------------------------------------------
void SerialSend(void)
{
	int16_t i = 0;
	char *pt = &serial.sbuffer[0];
	TXD_EN;
	UCSR0A |= (1<<TXC0);
	
	while ((i < SERIAL_SBUFFER_SIZE) && (*pt)) {
		while(!(UCSR0A & 1<<UDRE0)){};
		UDR0 = *pt;		
		pt++;
		i++;
	};
	
	while(!(UCSR0A & 1<<TXC0)){};
	TXD_DIS;

	serial.sindex = 0;	
}

//------------------------------------------
void SerialSendLen(char len)
{
	int16_t i = 0;
	char *pt = &serial.sbuffer[0];
	TXD_EN;
	UCSR0A |= (1<<TXC0);
	
	while ((i < SERIAL_SBUFFER_SIZE) && (len > 0)) {
		while(!(UCSR0A & 1<<UDRE0)){};
		UDR0 = *pt;
		pt++;
		i++;
		len--;
	};
	
	while(!(UCSR0A & 1<<TXC0)){};
	TXD_DIS;

	serial.sindex = 0;
}

//-------------------------------------
void SerialByte(char data)
{
	TXD_EN;
	UCSR0A |= (1<<TXC0);
	while(!(UCSR0A & 1<<UDRE0));
	UDR0 = data;
	while(!(UCSR0A & 1<<TXC0)){};
	TXD_DIS;
}

