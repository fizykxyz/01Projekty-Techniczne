/*
 * serial.h
 *
 * Created: 2016-01-15 12:16:44
 *  Author: dsosnowski
 */ 


#ifndef SERIAL_H_
#define SERIAL_H_



#define SERIAL_RBUFFER_SIZE		32
#define SERIAL_SBUFFER_SIZE		32

#define SERIAL_PREFIX			COMMAND_CODE	
#define SERIAL_POSTFIX			COMMAND_ENTER				
#define SERIAL_STATUS_IDLE		0
#define SERIAL_STATUS_READING	1
#define SERIAL_STATUS_READY		2

#define COMMAND_STATUS_IDLE		0
#define COMMAND_STATUS_READING	1
#define COMMAND_STATUS_READY	2
#define COMMAND_STATUS_ERROR	3

#define COMMAND_OFFSET			0
#define ADDRESS_OFFSET			1
	
#define COMMAND_CODE			'R'
#define COMMAND_DEF_ADR			0	
#define COMMAND_ENTER			'\r'
#define COMMAND_CONTROL			'='
#define COMMAND_SEPARATOR		','

#define ORDER_SET				'='		
#define ORDER_ADD				'+'
#define ORDER_CURSOR			'>'
#define ORDER_ACTION			'!'
#define ORDER_BKL				'#'
#define ORDER_CHECK				'?'

#define ERROR_NO				0
#define ERROR_OTHER_PARAM		0
#define ERROR_PARAM				1
#define ERROR_COMMAND			2
#define ERROR_ADDRESS			3
#define ERROR_CONTROL			4
#define ERROR_OTHER				5



void SerialInit(void);
char SerialStatus(void);

void CommInit(void);
void CommClear(void);
char *CommGet(void);
char *CommGetPt(void);
char CommOrder(void);
int16_t CommParam1(void);
int16_t CommParam2(void);
char CommStatus(void);
char CommError(void);
char CommProc(void);
int16_t CommValueGet(void);
uint16_t CommHexValueGet(char *pt);
void CommResult(void);

void SerialNew(void);
void SerialMsg(char *src);
char SerialAdd(char *src);
char SerialAddLen(char *src, char len);
void SerialAddVal(int16_t val);
void SerialAddHex(uint16_t val);
void SerialSend(void);

void SerialByte(char data);

#endif /* SERIAL_H_ */