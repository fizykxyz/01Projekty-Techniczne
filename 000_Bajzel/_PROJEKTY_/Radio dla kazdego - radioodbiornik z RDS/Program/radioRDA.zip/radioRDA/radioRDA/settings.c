/*
 * settings.c
 *
 * Created: 2016-01-19 14:37:57
 *  Author: dsosnowski
 */ 

#include "defs.h"
#define F_CPU MAIN_CLK
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "lcd.h"
#include "ui.h"
#include "serial.h"
#include "radio.h"
#include "settings.h"






//--------------------------------------------------------------
struct {
	uint16_t freq;
	uint16_t volume;
	char active;
	char program;
	uint16_t programs[SETT_PRG_MAX + 1];	
} sett;

//--------------------------------------------------------------
void SettInit(void) {
	char data;
	
	SettRestore(&sett.programs[0], 8, 18);

	data = (sett.programs[0] & 0xFF);

	if ((data < 1) || (data > SETT_PRG_MAX)) {
		sett.programs[0] = (SETT_PRG_DEFAULT + (SETT_VOLUME_DEFAULT<<8));
		sett.programs[1] = 898;
		sett.programs[2] = 910;
		sett.programs[3] = 940;
		sett.programs[4] = 966;
		sett.programs[5] = 1010;
		sett.programs[6] = 1044;
		sett.programs[7] = 1056;	
		sett.programs[8] = 1075;
	}

	data = (sett.programs[0] & 0xFF);
		sett.program = data;
	
	data = ((sett.programs[0] >> 8) & 0xFF);
		sett.volume = data;
	
	if ((sett.program < 1) || (sett.program > SETT_PRG_MAX)) sett.program = SETT_PRG_DEFAULT;
		sett.freq = sett.programs[sett.program];

	if ((sett.freq < SETT_FREQ_MIN) || (sett.freq > SETT_FREQ_MAX)) sett.freq = SETT_FREQ_DEFAULT;

	if ((sett.volume < SETT_VOLUME_MIN) || (sett.volume > SETT_VOLUME_MAX)) sett.volume = SETT_VOLUME_DEFAULT;
}

//--------------------------------------------------------------
char SettFreqChange(char action) {
	int16_t comp = sett.freq;
	
	if (action == ACTION_IMP2R) sett.freq++;
	if (action == ACTION_IMP2L) sett.freq--;
	if (action == ACTION_IMP2R + ACTION_MULTI) sett.freq += SETT_LARGE_STEP;
	if (action == ACTION_IMP2L + ACTION_MULTI) sett.freq -= SETT_LARGE_STEP;
	if (sett.freq < SETT_FREQ_MIN) sett.freq = SETT_FREQ_MIN;
	if (sett.freq > SETT_FREQ_MAX) sett.freq = SETT_FREQ_MAX;
	
	if (comp != sett.freq) return 1;
	return 0;	
}

//--------------------------------------------------------------
char SettVolChange(char action) {
	int16_t comp = sett.volume;
	
	if (action == ACTION_IMP1R) sett.volume++;
	if (action == ACTION_IMP1L) sett.volume--;
	if (action == ACTION_IMP1R + ACTION_MULTI) sett.volume++;
	if (action == ACTION_IMP1L + ACTION_MULTI) sett.volume--;
	if (sett.volume < SETT_VOLUME_MIN) sett.volume = SETT_VOLUME_MIN;
	if (sett.volume > SETT_VOLUME_MAX) sett.volume = SETT_VOLUME_MAX;

	if (comp != sett.volume) return 1;
	return 0;
}

//--------------------------------------------------------------
int16_t SettFreqGet(void) {
	return sett.freq;
}

//--------------------------------------------------------------
int16_t SettVolGet(void) {
	return sett.volume;
}

//-------------------------------------------------
char SettMode(char action) {
	if (action) sett.active++;
	return (sett.active & 1);
}

//--------------------------------------------------------------
void SettProgramChange(char action) {
	int16_t comp = sett.freq;
	
	if (action == ACTION_IMP2R) {
		if (sett.program < SETT_PRG_MAX) sett.program++;
	}

	if (action == ACTION_IMP2L) {
		if (sett.program > 1) sett.program--;
	}
	
	if (sett.program == 0) sett.program = 1;
	if (sett.program > SETT_PRG_MAX) sett.program = SETT_PRG_MAX;
}

//--------------------------------------------------------------
void SettProgramNext(void) {
	if (sett.program < SETT_PRG_MAX) 
		sett.program++;
	else
		sett.program = 1;
		
	if ((sett.programs[sett.program] < SETT_FREQ_MIN) || 
		(sett.programs[sett.program] > SETT_FREQ_MAX)) {
		sett.program = 1;	
	}
		
	sett.freq = sett.programs[sett.program];
}

//--------------------------------------------------------------
char SettProgramCheck(void) {
	char i;
	char result;
	
	i = 1;
	result = 0;
	while (result == 0) {
		if (sett.freq == sett.programs[i]) result = i;
		if (i > SETT_PRG_MAX) break;
		i++;
	}
	return result;
}

//--------------------------------------------------------------
char SettProgramGet(void) {
	if (sett.program == 0) sett.program = 1;
	if (sett.program > SETT_PRG_MAX) sett.program = SETT_PRG_MAX;
	return sett.program;
}

//--------------------------------------------------------------
void SettProgramSave(void) {
	sett.programs[sett.program] = sett.freq;
	sett.programs[0] = sett.program;
	sett.programs[0] += ((sett.volume & 0xFF) << 8);
	SettStore(&sett.programs[0], 8, 18);
}

//---------------------------------
void SettStore(char *pt, char adr, char len)
{
	while (len)
	{
		EEwrite(adr, *pt);
		adr++;
		pt++;
		len--;
	}
}

//---------------------------------
void SettRestore(char *pt, char adr, char len)
{
	while (len)
	{
		*pt = EEread(adr);
		adr++;
		pt++;
		len--;
	}
}

//---------------------------------
void EEwrite(uint16_t address, char data)
{
	while(EECR & (1<<EEPE)); 		//Wait for completion of previous write
	EECR = 0;						//Set Programming mode

	EEAR = address;					//Set up address and data registers
	EEDR = data;

	EECR |= (1<<EEMPE);				//Write logical one to EEMPE
	EECR |= (1<<EEPE);				//Start eeprom write by setting EEPE
}

//---------------------------------
char EEread(uint16_t address)
{
	while(EECR & (1<<EEPE));		//Wait for completion of previous write
	
	EEAR = address;					//Set up address register
	EECR |= (1<<EERE);				//Start eeprom read by writing EERE
	
	return EEDR;					//Return data from data register
}