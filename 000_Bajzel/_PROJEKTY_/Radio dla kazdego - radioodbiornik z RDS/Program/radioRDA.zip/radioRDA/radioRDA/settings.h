/*
 * settings.h
 *
 * Created: 2016-01-19 14:38:20
 *  Author: dsosnowski
 */ 


#ifndef SETTINGS_H_
#define SETTINGS_H_



#define SETT_LARGE_STEP		5

#define SETT_FREQ_MAX		RADIO_FREQ_MAX
#define SETT_FREQ_MIN		RADIO_FREQ_MIN
#define SETT_FREQ_DEFAULT	1010

#define SETT_PRG_MAX		8
#define SETT_PRG_DEFAULT	5

#define SETT_VOLUME_MAX		(RADIO_VOLUME_MAX + 1)
#define SETT_VOLUME_MIN		0
#define SETT_VOLUME_DEFAULT	3


void SettInit(void);
char SettFreqChange(char action);
char SettVolChange(char action);
int16_t SettFreqGet(void);
int16_t SettVolGet(void);

char SettMode(char action);
void SettProgramChange(char action);
void SettProgramNext(void);
char SettProgramCheck(void);
char SettProgramGet(void);
void SettProgramSave(void);

void SettStore(char *pt, char adr, char len);
void SettRestore(char *pt, char adr, char len);
void EEwrite(uint16_t address, char data);
char EEread(uint16_t address);
#endif /* SETTINGS_H_ */