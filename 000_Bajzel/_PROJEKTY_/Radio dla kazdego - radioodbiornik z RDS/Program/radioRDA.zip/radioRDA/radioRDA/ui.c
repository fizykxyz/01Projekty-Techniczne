/*
 * ui.c
 *
 * Created: 2015-12-31 08:07:03
 *  Author: dsosnowski
 */ 


#include "defs.h"
//#define F_CPU		MAIN_CLK
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "ui.h"


#define BUTTON_THRESHOLD			(1000 / MAIN_DELAY)
#define BUTTON_REPEAT				(20 / MAIN_DELAY)

struct {
	volatile char action;	
} buttons;

struct {
	char bkl;
	
} interface;



//-------------------------------------------------
void UiInit(void) {
	UI_PORT |= (1<<IMP1_A | 1<<IMP1_B | 1<<IMP2_A | 1<<IMP2_B | 1<<SW1_PIN | 1<<SW2_PIN);

	//PCMSK2 = (1<<PCINT18 | 1<<PCINT19 | 1<<PCINT22 | 1<<PCINT23);
	//PCICR = (1<<PCIE2);

	//back light
	LCD_COM_PORT |= (1<<LCD_BKL);
	LCD_COM_DDR |= (1<<LCD_BKL);
	
	OCR2A = 0xFF;
	TCCR2A = (1<<COM2A1 | 1<<WGM21 | 1<<WGM20);
	TCCR2B = (0<<CS22 | 1<<CS20);
}

//-------------------------------------------------
ISR (PCINT2_vect) {

}

//-------------------------------------------------
void UiScan(void) {
	static char prev1;
	static char prev2;
	static char mem;
	static char ia;
	static char ib;	
	char pin;
	
	char button;
	static uint16_t hold;
	static char prev;
	
	pin = UI_IN;
	
	//--------------------------------------------------------
	if (ia < 0xFF) ia++;
	
	if (pin & (1<<IMP1_A)) {
		prev1 = 0;
	} else {
		if (prev1 == 0) {
			if (ia > ACTION_IMP_THR) {
				if (pin & (1<<IMP1_B)) {
					buttons.action = ACTION_IMP1R;
					mem = ACTION_IMP1R;
				} else {
					buttons.action = ACTION_IMP1L;
					mem = ACTION_IMP1L;
				}			
			} else {
				buttons.action = mem;
			}
			ia = 0;
		}
		prev1 = 1;	
	}
	
	//--------------------------------------------------------
	if (ib < 0xFF) ib++;
	
	if (pin & (1<<IMP2_A)) {
		prev2 = 0;
	} else {
		if (prev2 == 0) {
			if (ib > ACTION_IMP_THR) {
				if (pin & (1<<IMP2_B)) {
					buttons.action =  ACTION_IMP2L;
					mem = ACTION_IMP2L;
				} else {
					buttons.action =  ACTION_IMP2R;
					mem = ACTION_IMP2R;
				}
			} else {
				buttons.action = mem;
			}
			ib = 0;
		}
		prev2 = 1;
	}
	
	//--------------------------------------------------------
	button = 0;
	if ((pin & (1<<SW1_PIN)) == 0) button = ACTION_SW1;
	if ((pin & (1<<SW2_PIN)) == 0) button = ACTION_SW2;
	
	if (button == 0) {
		if ((hold > 0) && (hold < BUTTON_THRESHOLD)) {
			buttons.action = prev;
		}
		prev = 0;
		hold = 0;
	}
	else
	{
		if (hold < BUTTON_THRESHOLD) hold++;
		if (button != prev) hold = 0;
		prev = button;
		button = 0;
		
		if (hold >= BUTTON_THRESHOLD) {
			buttons.action = prev + ACTION_HOLD;
			//if ((prev == ACTION_SW1) || (prev == ACTION_SW2)) {
			//	hold -= BUTTON_REPEAT;
			//}
		}
	}
	
	buttons.action += UiActionMulti(buttons.action);
}

//-------------------------------------------------
char UiActionMulti(char button) {
	static char i; 
	static char prev;
	static char pass_button;
	char result = 0;
	
	if (i <= ACTION_MULTI_TIM) i++;
	if (i == ACTION_MULTI_TIM) {
		prev = 0;
		pass_button = 0;
	}

	if (button > ACTION_IDLE) {
		i = 0;

		if (button == prev) {
			if (pass_button < ACTION_PASS_COUNTER) {
				pass_button++;
			}	
		} else {
			pass_button = 0;
		}
		prev = button;		

		if (pass_button >= ACTION_PASS_COUNTER) {
			result = ACTION_MULTI;
		}		
	}
	return result;
}

//-------------------------------------------------
char UiActionGet(void) {
	/*char reg = buttons.action;
	buttons.action = 0;
	return reg;*/
	return buttons.action;
}

//-------------------------------------------------
void UiActionClear(void) {
	buttons.action = 0;
}

//---------------------------------------------------
/*void UiBkl(char state)
{
	if (state)
	LCD_COM_PORT &= ~(1<<LCD_BKL);
	else
	LCD_COM_PORT |= (1<<LCD_BKL);
}*/

//---------------------------------------------------
void UiBklVal(char val) {
	interface.bkl = val;
}

//---------------------------------------------------
void UiBklProcess(void) {
	if (OCR2A < interface.bkl) OCR2A++;
	
	if (OCR2A > interface.bkl) OCR2A--;	
}