/*
 * ui.h
 *
 * Created: 2015-12-31 08:06:50
 *  Author: dsosnowski
 */ 


#ifndef UI_H_
#define UI_H_

void UiInit(void);
void UiScan(void);
char UiActionMulti(char button);
char UiActionGet(void);
void UiActionClear(void);

void UiBklVal(char val);
void UiBklProcess(void);

#define ACTION_IDLE			0
#define ACTION_IMP1R		1
#define ACTION_IMP1L		2
#define ACTION_IMP2R		3
#define ACTION_IMP2L		4
#define ACTION_MULTI		16

#define ACTION_SW1			5
#define ACTION_SW2			6
#define ACTION_SPECIAL		7

#define ACTION_SW1H			(ACTION_SW1 + ACTION_HOLD)
#define ACTION_SW2H			(ACTION_SW2 + ACTION_HOLD)
#define ACTION_HOLD			16

#define ACTION_MULTI_TIM	(300 / MAIN_DELAY)
#define ACTION_IMP_THR		(100 / MAIN_DELAY)
#define ACTION_PASS_COUNTER	8

#define INTEFRACE_BKL_LOW	96
#define INTEFRACE_BKL_MAX	0



#endif /* UI_H_ */